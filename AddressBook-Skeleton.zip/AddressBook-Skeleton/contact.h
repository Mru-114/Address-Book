#ifndef CONTACT_H
#define CONTACT_H

#define MAX_CONTACTS 100

#define RED "\033[0;31m"
#define GREEN "\033[0;32m"
#define BLUE "\033[0;34m"
#define RESET "\033[0m" 

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include<stdlib.h>

typedef struct {
    char name[50];
    char phone[20];
    char email[50];
} Contact;


typedef struct {
    Contact contacts[100];
    int contactCount;
} AddressBook;

void createContact(AddressBook *addressBook);
void searchContact(AddressBook *addressBook);
void editContact(AddressBook *addressBook);
void deleteContact(AddressBook *addressBook);
void listContacts(AddressBook *addressBook);
void initialize(AddressBook *addressBook);
void saveContact(AddressBook *AddressBook);

//Function call for create contact
int validate_name(AddressBook *addressBook, char name[]);
int validate_phone(AddressBook *addressBook, char phone[]);
int validate_email(AddressBook *addressBook, char email[]);

//Function call for Search contact
int searchbyName(AddressBook *addressBook);
int searchbyPhone(AddressBook *addressBook);
int searchbyEmail(AddressBook *addressBook);


//Function call for edit contact
int namebasedEdit(AddressBook *addressBook);
int phonebasedEdit(AddressBook *addressBook);
int emailbasedEdit(AddressBook *addressBook);

#endif
