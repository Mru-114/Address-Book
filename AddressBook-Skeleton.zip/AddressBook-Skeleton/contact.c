#include "contact.h"

void listContacts(AddressBook *addressBook) 
{
    //Check if the address book is empty
    int i;
    printf("Sl.no \t Name\t\t Phone number \t Email \t\n");
    for(i=0; i<=addressBook->contactCount; i++)
    {
        printf(" %d\t", i+1);
        printf("%s \t",addressBook->contacts[i].name);
        printf("%s \t",addressBook->contacts[i].phone);
        printf("%s \t",addressBook->contacts[i].email);
        printf("\n");
    }
}

void createContact(AddressBook *addressBook) 
{
    char name[50];
    char phone[20];
    char email[50];

    //Validate name
    do
    {
        printf("Enter the name: ");
        scanf(" %[^\n]", name);
    }
    while(validate_name(addressBook, name) == 1);
    

    //Validate phone
     do
    {
        printf("Enter the phone: ");
        scanf(" %[^\n]", phone);
    }
    while(validate_phone(addressBook, phone) == 1);
    
    //Validate email
     do
    {
        printf("Enter the email: ");
        scanf(" %[^\n]", email);
    }
    while(validate_email(addressBook, email) == 1);

    strcpy(addressBook->contacts[addressBook->contactCount].name, name);
    strcpy(addressBook->contacts[addressBook->contactCount].phone, phone);
    strcpy(addressBook->contacts[addressBook->contactCount].email, email); 
      
    addressBook->contactCount++;
    printf(GREEN"Contact created successfully...\n\n"RESET); 
}

int validate_name(AddressBook *addressBook, char name[])
{
    int i;

    //To check if the name is already present in the address book contact list
    for(i=0; i<(addressBook->contactCount); i++)
    {
        if(strcasecmp(name, addressBook->contacts[i].name) == 0)
        {
            printf(RED "Name already exists\n" RESET);
            return 1;           //Name is already present in the list
        }
    }

    //To check if it has character other than alphabet and space
    for(i=0; name[i] != '\0'; i++)
    {
        if(!isalpha(name[i]) && name[i] !=' ')
        {
            printf(RED "Invalid name\n"RESET);
            return 1;           //Name has character other than alphabets and space
        }    
    }
    return 0;                   //name is unique return 0
}

int validate_phone(AddressBook *addressBook, char phone[])
{
    //To check if the number is already present in the AddressBook contacts list
    int i;
    for(i=0; i<(addressBook->contactCount); i++)
    {
        if(strcmp(phone, addressBook->contacts[i].phone) == 0)
        {
            printf(RED "Phone already exists\n" RESET);
            return 1;
        }
    }

    //Check if the number is 10 digits
    if(strlen(phone) != 10)
    {
        printf(RED "Invalid phone number\n" RESET);
        return 1;
    }

    //Check if the number is only numeric
    for(i=0; phone[i] != '\0'; i++)
    {
        if(!isdigit(phone[i]))
        {
            printf(RED "Invalid phone number\n" RESET);
            return 1;
        }
    }
    return 0;
}

int validate_email(AddressBook *addressBook, char email[])
{
    //Check if email is already present
    int i;
    int len = strlen(email);
    for(i=0; i<(addressBook->contactCount); i++)
    {
        if(strcmp(email, addressBook->contacts[i].email) == 0)
        {
            printf(RED "Email already exists\n" RESET);
            return 1;
        }
    }

    //Check if the entered address has capital letter or space
    for(i=0; email[i] != '\0'; i++)
    {
        if((email[i] >= 'A' && email[i] <= 'Z') || email[i] == ' ')
        {
            printf(RED "Invalid email\n" RESET);
            return 1;
        }
    }

    //Check if the email has @ in the mail
    char *ptr1 = strchr(email, '@'); 
    if(ptr1 == NULL)
    {
        printf(RED "Invalid email\n" RESET);
        return 1;
    }

    //Check if email has .com
    char *ptr2 = strstr(email,".com");
    if(ptr2 == NULL || ptr2 == 0) 
    {
        printf(RED "Invalid email\n" RESET);
        return 1;
    }

    //Check if there is minimum 1 character between @ and .com
    
    if(ptr2 <= ptr1+1) 
    {
        printf(RED "Invalid email\n" RESET);
        return 1;
    }

    if(email[len-4] != '.')
    {
        printf(RED "Invalid email\n" RESET);
        return 1;
    }
    //All the conditions get false means email is valid
    return 0;
}
void searchContact(AddressBook *addressBook) 
{
    int option;

    printf("On what basis would you like to search the contact?\n");
    printf("1. Name\n2. Phone\n3. Email\n");
    scanf("%d", &option);

    switch (option)
    {
        case 1:
            searchbyName(addressBook);
            break;
        case 2:
            searchbyPhone(addressBook);
            break;
        case 3:
            searchbyEmail(addressBook);
            break;
        default:
            printf(RED "Invalid option selected\n" RESET);
            return;
    }
   
}

int searchbyName(AddressBook *addressBook)
{
    int i, flag = 0;
    char find[50];

    printf("Enter the name: ");
    scanf(" %[^\n]", find);

    int slno=1;
    for(i=0; i<addressBook->contactCount; i++)
    {
        if(strcasestr(addressBook->contacts[i].name, find) != '\0')
        {
            printf(" %d\t", slno);
            printf("%s \t",addressBook->contacts[i].name);
            printf("%s \t",addressBook->contacts[i].phone);
            printf("%s \t",addressBook->contacts[i].email);
            printf("\n");
            slno++;
            flag = 1;
        }
    }
    if(flag != 1)
    printf(RED "Contact not found\n" RESET);
}

int searchbyPhone(AddressBook *addressBook)
{
    int i, flag=0;
    char find[50];
    printf("Enter the phone number: ");
    scanf(" %[^\n]", find);

    int slno=1;
    for(i=0; i<addressBook->contactCount; i++)
    {
        if(strcasestr(addressBook->contacts[i].phone, find) != '\0')
        {
            printf(" %d\t",slno);
            printf("%s \t",addressBook->contacts[i].name);
            printf("%s \t",addressBook->contacts[i].phone);
            printf("%s \t",addressBook->contacts[i].email);
            printf("\n");
            slno++;
            flag = 1;
        }
    }
    if(flag != 1)
    printf(RED "Contact not found\n" RESET);
}

int searchbyEmail(AddressBook *addressBook)
{
    int i, flag=0;
    char find[50];
    printf("Enter the email: ");
    scanf(" %[^\n]", find);

    int slno = 1;
    for(i=0; i<addressBook->contactCount; i++)
    {
        if(strcasestr(addressBook->contacts[i].email, find) != '\0')
        {
            printf(" %d\t",slno);
            printf("%s \t",addressBook->contacts[i].name);
            printf("%s \t",addressBook->contacts[i].phone);
            printf("%s \t",addressBook->contacts[i].email);
            printf("\n");
            slno++;
            flag = 1;
        }
    }
    if(flag != 1)
    printf(RED"Contact not found\n"RESET);
    
}
void editContact(AddressBook *addressBook) 
{
    int option;

    printf("On what basis would you like to search the contact?\n");
    printf("1. Name\n2. Phone\n3. Email\n");
    scanf("%d", &option);

    switch(option)
    {
        case 1:
            namebasedEdit(addressBook);
            break;
        case 2:
            phonebasedEdit(addressBook);
            break;
        case 3:
            emailbasedEdit(addressBook);
            break;
        default:
            printf(RED "Invalid option" RESET);
    }
}

int namebasedEdit(AddressBook *addressBook)
{
    char find[50];
    int i, Slno=0, count=1, flag=0;

    //Read the name from the user
    printf("Enter the name: ");
    scanf(" %[^\n]", find);

    //List all the contacts including the substring
    printf("Sl.no\tName\t\tPhone\tEmail\t\n");
    for(i=0; i<addressBook->contactCount; i++)
    {
        if(strcasestr(addressBook->contacts[i].name, find) != '\0')
        {
            Slno++;
            printf(" %d \t", Slno);
            printf("%s \t",addressBook->contacts[i].name);
            printf("%s \t",addressBook->contacts[i].phone);
            printf("%s \t",addressBook->contacts[i].email);
            flag = 1;
            printf("\n");
        }
    }
    if(flag != 1)
    {
        printf(RED "No contact found\n" RESET);
        return 0;
    }

    //Read the Slno from the user which the user wants to edit
    printf("Enter the Sl.no of the contact to be edited: ");
    scanf("%d", &Slno);
    count = 0;
    for(i=0; i<addressBook->contactCount; i++)
    {
        if(strcasestr(addressBook->contacts[i].name, find) != '\0')
        {
            count++;
        }
        if(count == Slno)
        {
            break;
        }
    }
    char editname[50];
    char editphone[20];
    char editemail[50];
    int ret;

    printf("Enter the name: ");
    scanf(" %[^\n]", editname);

    ret = validate_name(addressBook, editname);
    if(ret == 0)
    {
        printf("Enter the phone: ");
        scanf(" %[^\n]", editphone);

        ret = validate_phone(addressBook, editphone);
        if(ret == 0)
        {
            printf("Enter the email: ");
            scanf(" %[^\n]", editemail);

            ret = validate_email(addressBook, editemail);
            if(ret == 0)
            {
                strcpy(addressBook->contacts[i].name, editname);
                strcpy(addressBook->contacts[i].phone, editphone);
                strcpy(addressBook->contacts[i].email, editemail);
                printf(GREEN "Contact edited successfully...\n" RESET);
            }
        }
    }
}

int phonebasedEdit(AddressBook *addressBook)
{
    char find[50];
    int i, Slno=0, count=1, flag=0;

    //Read the name from the user
    printf("Enter the phone: ");
    scanf(" %[^\n]", find);

    //List all the contacts including the substring
    printf("Sl.no\tName\tPhone\tEmail\t\n");
    for(i=0; i<addressBook->contactCount; i++)
    {
        if(strcasestr(addressBook->contacts[i].phone, find) != '\0')
        {
            Slno++;
            printf(" %d \t", Slno);
            printf("%s \t",addressBook->contacts[i].name);
            printf("%s \t",addressBook->contacts[i].phone);
            printf("%s \t",addressBook->contacts[i].email);
            flag = 1;
            printf("\n");
        }
    }
    if(flag != 1)
    {
        printf(RED "No contact found\n" RESET);
        return 0;
    }

    //Read the Slno from the user which the user wants to edit
    printf("Enter the Sl.no of the contact to be edited: ");
    scanf("%d", &Slno);
    count = 0;
    for(i=0; i<addressBook->contactCount; i++)
    {
        if(strcasestr(addressBook->contacts[i].phone, find) != '\0')
        {
            count++;
        }
        if(count == Slno)
        {
            break;
        }
    }
    char editname[50];
    char editphone[20];
    char editemail[50];
    int ret;

    printf("Enter the name: ");
    scanf(" %[^\n]", editname);

    ret = validate_name(addressBook, editname);
    if(ret == 0)
    {
        printf("Enter the phone: ");
        scanf(" %[^\n]", editphone);

        ret = validate_phone(addressBook, editphone);
        if(ret == 0)
        {
            printf("Enter the email: ");
            scanf(" %[^\n]", editemail);

            ret = validate_email(addressBook, editemail);
            if(ret == 0)
            {
                strcpy(addressBook->contacts[i].name, editname);
                strcpy(addressBook->contacts[i].phone, editphone);
                strcpy(addressBook->contacts[i].email, editemail);
                printf(GREEN "Contact edited successfully...\n" RESET);
            }
        }
    }
}

int emailbasedEdit(AddressBook *addressBook)
{
    char find[50];
    int i, Slno=0, count=1, flag=0;

    //Read the name from the user
    printf("Enter the email: ");
    scanf(" %[^\n]", find);

    //List all the contacts including the substring
    printf("Sl.no\tName\tPhone\tEmail\t\n");
    for(i=0; i<addressBook->contactCount; i++)
    {
        if(strcasestr(addressBook->contacts[i].email, find) != '\0')
        {
            Slno++;
            printf(" %d \t", Slno);
            printf("%s \t",addressBook->contacts[i].name);
            printf("%s \t",addressBook->contacts[i].phone);
            printf("%s \t",addressBook->contacts[i].email);
            flag = 1;
            printf("\n");
        }
    }
    if(flag != 1)
    {
        printf(RED "No contact found\n" RESET);
        return 0;
    }

    //Read the Slno from the user which the user wants to edit
    printf("Enter the Sl.no of the contact to be edited: ");
    scanf("%d", &Slno);
    count = 0;
    for(i=0; i<addressBook->contactCount; i++)
    {
        if(strcasestr(addressBook->contacts[i].email, find) != '\0')
        {
            count++;
        }
        if(count == Slno)
        {
            break;
        }
    }
    char editname[50];
    char editphone[20];
    char editemail[50];
    int ret;

    printf("Enter the name: ");
    scanf(" %[^\n]", editname);

    ret = validate_name(addressBook, editname);
    if(ret == 0)
    {
        printf("Enter the phone: ");
        scanf(" %[^\n]", editphone);

        ret = validate_phone(addressBook, editphone);
        if(ret == 0)
        {
            printf("Enter the email: ");
            scanf(" %[^\n]", editemail);

            ret = validate_email(addressBook, editemail);
            if(ret == 0)
            {
                strcpy(addressBook->contacts[i].name, editname);
                strcpy(addressBook->contacts[i].phone, editphone);
                strcpy(addressBook->contacts[i].email, editemail);
                printf(GREEN "Contact edited successfully...\n" RESET);
            }
        }
    }
}

void deleteContact(AddressBook *addressBook) 
{
    char delete[50];
    int i, j, flag=0, icf;                              //icf -> Value of i where the contact is found
    char ch;

    printf("Enter the contact to be deleted: \n");
    scanf(" %[^\n]", delete);

    for(i=0; i<addressBook->contactCount; i++)
    {
        if(strcasecmp(addressBook->contacts[i].name, delete) == 0)
        {
            flag = 1;
            icf = i;
            break;
        }
    }

    if(flag != 1)
    {
        printf(RED "No contact found\n" RESET);
        printf("Do you want to continue?\n");
        printf("Yes or No\n");
        scanf(" %c", &ch);

        if(ch == 'N' || ch =='n')
        return;
        else if(ch == 'Y' || ch == 'y')
        {
            deleteContact(addressBook);
        }
    }
    
    else if(flag == 1)
    {
        printf(BLUE"Do you want to delete this contact?\n"RESET);
        printf(" %s \t", addressBook->contacts[i].name);
        printf("%s \t", addressBook->contacts[i].phone);
        printf("%s \t\n", addressBook->contacts[i].email);
        printf("Yes or No\n");
        scanf(" %c", &ch);
        if(ch == 'Y' || ch == 'y')
        {
            for(i = icf; i<addressBook->contactCount; i++)
            {
                strcpy(addressBook->contacts[i].name, addressBook->contacts[i+1].name);
                strcpy(addressBook->contacts[i].phone, addressBook->contacts[i+1].phone);
                strcpy(addressBook->contacts[i].email, addressBook->contacts[i+1].email);
            }
            addressBook->contactCount--;
            printf(GREEN"Contact deleted successfully...\n\n"RESET);
        }
        else if(ch == 'N' || ch == 'n')
        {
            return;
        }
    }
}

void saveContact(AddressBook *AddressBook)
{
    FILE *fp = fopen("contact.txt","w");
    int i;
    for(i=0; i<AddressBook->contactCount; i++)
    {
        fprintf(fp,"%s",AddressBook->contacts[i].name);
        fputc(',',fp);
        fprintf(fp,"%s",AddressBook->contacts[i].phone);
        fputc(',',fp);
        fprintf(fp,"%s",AddressBook->contacts[i].email);
        fputc('\n',fp);
    }
    printf(GREEN "Contacts saved successfully\n" RESET);
    fclose(fp);
}