/*
Name: Mrunal Halgekar
Date:
Description: To create a address book which has contact list of multiple people through which we can list, create, delete, search and edit the contact
*/
#include "contact.h"
#include<stdlib.h>
int main()
{
    AddressBook addressBook;

    //Call initialize function
    initialize(&addressBook);

    int choice;
    while(1)
    {
        printf("Enter your choice: \n");
        printf("1. List contacts \n2. Create contact \n3. Search contact \n4. Edit contact \n5. Delete contact \n6. Save contacts \n7. Exit \n");
        scanf("%d", &choice);
        switch(choice)
        {
            case 1:
            {
                listContacts(&addressBook);
                break;
            }
            case 2:
            {
                createContact(&addressBook);
                break;
            }
            case 3:
            {
                searchContact(&addressBook);
                break;
            }
            case 4:
            {
                editContact(&addressBook);
                break;
            }
            case 5:
            {
                deleteContact(&addressBook);
                break;
            }
            case 6:
            {
                saveContact(&addressBook);
                break;
            }
            case 7:
            {
                exit(0);
            }
            default:
            printf("Invalid choice");
        }
    }
}
